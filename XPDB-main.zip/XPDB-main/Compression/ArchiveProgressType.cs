﻿namespace XPDB.Compression
{
    public enum ArchiveProgressType
	{
		StartFile,
		PartialFile,
		FinishFile,
		StartArchive,
		PartialArchive,
		FinishArchive
	}
}

﻿namespace XPDB.Compression
{
    public enum ECompressionLevel
	{
		None,
		Min,
		Normal = 6,
		Max = 10
	}
}

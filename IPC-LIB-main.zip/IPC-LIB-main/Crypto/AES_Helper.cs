﻿namespace IPC_LIB.Crypto
{
    public static class AES_Helper
    {
        public readonly struct Sizes
        {
            public const int IV = 16;
            public const int Key = 16;
        }
    }
}

﻿namespace Tarkov_DMA_Backend.LowLevel.Compression
{
    public enum ArchiveProgressType
	{
		StartFile,
		PartialFile,
		FinishFile,
		StartArchive,
		PartialArchive,
		FinishArchive
	}
}

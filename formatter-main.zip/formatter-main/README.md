# Formatter

A helper utility to format using prettier
